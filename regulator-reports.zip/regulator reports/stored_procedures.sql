exec pk_stat_reports.pr_del_x_data;

exec pk_stat_reports.pr_pop_x_data('01-Jun-2017','30-Jun-2017');